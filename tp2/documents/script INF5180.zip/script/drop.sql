--
-- Script de nettoyage
-- Auteurs
-- Code permanent:
-- Code permanent:
--
SET ECHO ON

-- ecrire sql ici

SET ECHO OFF
