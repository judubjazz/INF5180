--
-- Script de creation des tables
-- Auteurs
-- Code permanent:
-- Code permanent:
-- 
--
SET ECHO ON

-- ecrire sql ici

SET ECHO OFF



